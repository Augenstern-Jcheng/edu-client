<template>
  <div class="resource">资源管理</div>
</template>

<script>
export default {
  name: 'resource'
}
</script>
<style lang='scss' scoped></style>
