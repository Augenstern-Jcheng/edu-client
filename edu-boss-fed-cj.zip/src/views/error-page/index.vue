<template>
  <div class="error-page">404</div>
</template>

<script>
export default {
  name: 'error-page'
}
</script>
<style lang='scss' scoped></style>
