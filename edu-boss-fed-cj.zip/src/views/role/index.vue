<template>
  <div class="role">角色管理</div>
</template>

<script>
export default {
  name: 'role'
}
</script>
<style lang='scss' scoped></style>
