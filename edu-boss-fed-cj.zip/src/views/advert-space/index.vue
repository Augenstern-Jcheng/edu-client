<template>
  <div class="advent-space">广告位管理</div>
</template>

<script>
export default {
  name: 'advent-space'
}
</script>
<style lang='scss' scoped></style>
