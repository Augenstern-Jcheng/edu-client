<template>
  <div class="user">用户管理</div>
</template>

<script>
export default {
  name: 'user'
}
</script>
<style lang='scss' scoped></style>
