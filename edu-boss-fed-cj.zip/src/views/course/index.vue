<template>
  <div class="course">课程管理</div>
</template>

<script>
export default {
  name: 'course'
}
</script>
<style lang='scss' scoped></style>
