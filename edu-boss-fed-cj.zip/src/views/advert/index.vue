<template>
  <div class="advent">广告管理</div>
</template>

<script>
export default {
  name: 'advent'
}
</script>
<style lang='scss' scoped></style>
