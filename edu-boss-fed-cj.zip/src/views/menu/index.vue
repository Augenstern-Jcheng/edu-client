<template>
  <div class="menu">菜单管理</div>
</template>

<script>
export default {
  name: 'menu'
}
</script>
<style lang='scss' scoped></style>
